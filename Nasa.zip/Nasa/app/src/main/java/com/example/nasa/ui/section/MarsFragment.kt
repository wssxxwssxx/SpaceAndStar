package com.example.nasa.ui.section

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.nasa.R
import com.example.nasa.databinding.FragmentMarsBinding
import com.example.nasa.service.mars.PhotosMarsListVO
import dagger.hilt.android.AndroidEntryPoint
import jp.wasabeef.glide.transformations.BlurTransformation
import kotlinx.android.synthetic.main.fragment_mars.view.*
import kotlinx.android.synthetic.main.fragment_start.view.*
import kotlinx.android.synthetic.main.fragment_start.view.image_back_start

@AndroidEntryPoint
class MarsFragment : Fragment() {
    val marsViewModel: MarsViewModel by viewModels()
    lateinit var recyclerAdapter: RecyclerViewAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentMarsBinding.inflate(inflater)
        marsViewModel.loadMarsPhotos()
        initViewModel(binding)
        initViewModel()
        loadImageGlide(binding.imageMarsPhotoBack)
        return binding.root
    }

    fun loadImageGlide(frameLayout: View) {
        Glide
            .with(this)
            .load(R.drawable.gradient)
            .apply(RequestOptions.bitmapTransform(BlurTransformation(5, 1)))
            .into(frameLayout.image_mars_photo_back)
    }

    fun initViewModel(binding: FragmentMarsBinding) {
        val recycler = binding.recyclerMarsPhoto
        recycler.layoutManager = GridLayoutManager(activity,2)
        val decortion = DividerItemDecoration(activity, DividerItemDecoration.VERTICAL)
        recycler.addItemDecoration(decortion)
        recyclerAdapter = context?.let { RecyclerViewAdapter(it) }!!
        recycler.adapter = recyclerAdapter
    }

    fun initViewModel() {
        marsViewModel.getRecyclerListObserver().observe(viewLifecycleOwner, Observer<PhotosMarsListVO>{
            if(it != null){
                recyclerAdapter.setUpdateData(it.photosMarsList)
            }
        })
        marsViewModel.loadMarsPhotos()
    }
}