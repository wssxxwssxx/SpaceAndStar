package com.example.nasa.ui.section

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.nasa.service.mars.MarsApi
import com.example.nasa.service.mars.PhotosMarsListVO
import dagger.hilt.android.lifecycle.HiltViewModel
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MarsViewModel @Inject constructor(private val marsApi: MarsApi) : ViewModel() {

    val composite = CompositeDisposable()

    var recyclerListData: MutableLiveData<PhotosMarsListVO>

    init {
        recyclerListData = MutableLiveData()
    }

    fun getRecyclerListObserver(): MutableLiveData<PhotosMarsListVO> {
        return recyclerListData
    }

    fun loadMarsPhotos() {
        viewModelScope.launch {
            composite.add(
                marsApi.getPhotosBySol("curiosity", "1000")
                    .subscribeOn(Schedulers.computation())
                    .observeOn(AndroidSchedulers.mainThread())
                    .distinct()
                    .subscribe({ res ->
                        Thread.sleep(3000)
                        recyclerListData.postValue(res)
                    }, { error ->
                        error.printStackTrace()
                    })
            )
        }
    }

    override fun onCleared() {
        composite.dispose()
        super.onCleared()
    }
}