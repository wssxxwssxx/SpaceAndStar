package com.example.nasa.service.mars

import com.google.gson.annotations.SerializedName


data class PhotosMarsListVO (
    @SerializedName("photos")
    val photosMarsList: ArrayList<PhotoMars>
    )

data class PhotoMars(
//    @SerializedName("id")
//    val photoId: String,
//
//    @SerializedName("sol")
//    val solNumber: String,

    @SerializedName("img_src")
    val imgSource: String,

//    @SerializedName("earth_date")
//    val earthDate: String,
//
//    @SerializedName("camera")
//    val camera: Camera,
//
//    @SerializedName("rover")
//    val rover: Rover
)